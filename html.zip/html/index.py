import webapp2
import os
import time
import datetime
import random
import json
import sqlite3

conn = sqlite3.connect('/var/www/html/tutorial.db', check_same_thread=False)
c = conn.cursor()

def create_table():
  c.execute("CREATE TABLE IF NOT EXISTS polymer(Id TEXT, Count TEXT, Created TEXT)")

def data_entry(Id, Count):
  unix = int(time.time())
  date = str(datetime.datetime.fromtimestamp(unix).strftime('%Y-%m-%d %H:%M:%S'))
  c.execute("INSERT INTO polymer (Id, Count, Created) VALUES(?, ?, ?)",(Id, Count, date))
  conn.commit()
 

create_table()

form = """<!DOCTYPE html>
<html>
<head>
  <title>Internet Of Things</title>
</head> :
<body>
  <form method="post"> 
    <h2>ID :</h2>
  <input type="text" name="Id">
  <h2>State</h2>
  <input type="text" name="State">
  <input type="submit">
</body>
</html>"""

class Hello(webapp2.RequestHandler):
  def get(self):
    self.response.headers['Content-Type'] = 'text/html; charset=utf-8'
    self.response.out.write(form)
  def post(self):
   # self.response.headers['Content-Type'] = 'text/html; charset=utf-8'
    Id = self.request.get("Id")
    Count = self.request.get("State")
    data_entry(Id, Count)
    self.redirect('/')


class query(webapp2.RequestHandler):
  def get(self):
    Id = self.request.get("Id")
    if Id:
      c.execute("SELECT * FROM polymer WHERE Id = ?",(Id,))
      #datas = c.fetchall()
      rows = [x for x in c.fetchall()]
      cols = [x[0] for x in c.description]
      songs = []
      for row in rows:
        song = {}
        for prop, val in zip(cols, row):
          song[prop] = val
        songs.append(song)
      self.response.headers['Content-Type'] = 'text/html; charset=utf-8'
      self.response.write(json.dumps(songs))
    else:
      error = "Please Give any bin number"
      self.response.headers['Content-Type'] = 'text/html; charset=utf-8'
      self.response.write(json.dumps(error))

application = webapp2.WSGIApplication([
    ('/', Hello),('/query', query)
], debug=True)
